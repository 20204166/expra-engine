"""Entity — a named game object with components.

Entities have stable UUIDs, a name, an enabled flag, and an ordered list of
components. Hierarchy (parent/child) is supported via optional parent_id.
"""

from __future__ import annotations

import contextlib
import uuid
from typing import TYPE_CHECKING, Any, TypeVar

from expra_engine.core.component import Component, component_from_dict

if TYPE_CHECKING:
    from expra_engine.runtime.behaviour import Behaviour, BehaviourFactory
    from expra_engine.runtime.events import Update
    from expra_engine.runtime.input import ActionEvent

C = TypeVar("C", bound=Component)


class Entity:
    """A named game object that holds components.

    ``entity_id`` is a stable UUID string. IDs survive serialization
    round-trips; never regenerate them on load.
    """

    def __init__(
        self,
        name: str,
        *,
        entity_id: str | None = None,
        enabled: bool = True,
        layer: int = 0,
        parent_id: str | None = None,
    ) -> None:
        self.entity_id: str = entity_id or str(uuid.uuid4())
        self.name = name
        self.enabled = enabled
        self.layer = layer
        self.parent_id = parent_id
        self._components: list[Component] = []
        self._behaviours: list[Behaviour] = []
        self._behaviour_factories: list[BehaviourFactory] = []
        self._tags: set[str] = set()

    @property
    def components(self) -> tuple[Component, ...]:
        return tuple(self._components)

    def add_component(self, component: Component) -> None:
        self._components.append(component)

    def remove_component(self, component: Component) -> bool:
        try:
            self._components.remove(component)
            return True
        except ValueError:
            return False

    def get_component(self, cls: type[C]) -> C | None:
        for component in self._components:
            if isinstance(component, cls):
                return component
        return None

    def get_components(self, cls: type[C]) -> list[C]:
        return [c for c in self._components if isinstance(c, cls)]

    @property
    def behaviours(self) -> tuple[Behaviour, ...]:
        """Return attached runtime behaviours in insertion order."""
        return tuple(self._behaviours)

    def add_behaviour(self, behaviour: Behaviour, *, runtime_factory: BehaviourFactory) -> None:
        """Attach an unowned runtime behaviour to this entity."""
        if not callable(runtime_factory):
            raise ValueError("runtime_factory must be callable")
        if behaviour.entity is not None:
            raise ValueError("behaviour is already owned by an entity")

        self._behaviours.append(behaviour)
        self._behaviour_factories.append(runtime_factory)
        behaviour.entity = self
        behaviour.on_attach(self)

    def remove_behaviour(self, behaviour: Behaviour) -> bool:
        """Detach a behaviour, returning whether it was attached."""
        try:
            index = self._behaviours.index(behaviour)
        except ValueError:
            return False

        self._behaviours.pop(index)
        self._behaviour_factories.pop(index)
        try:
            behaviour.on_detach()
        finally:
            behaviour.entity = None
        return True

    def get_behaviour(self, cls: type[Behaviour]) -> Behaviour | None:
        """Return the first attached behaviour matching ``cls``."""
        for behaviour in self._behaviours:
            if isinstance(behaviour, cls):
                return behaviour
        return None

    def on_update(self, event: Update, signal: Any) -> None:
        """Dispatch an update to the currently eligible behaviours."""
        for behaviour in tuple(self._behaviours):
            if not self.enabled or behaviour.entity is not self or not behaviour.enabled:
                continue
            behaviour.on_update(event, signal)

    def on_action_event(self, event: ActionEvent, signal: Any) -> bool:
        """Dispatch input until an eligible behaviour consumes it."""
        for behaviour in tuple(self._behaviours):
            if not self.enabled or behaviour.entity is not self or not behaviour.enabled:
                continue
            if behaviour.on_input(event, signal):
                return True
        return False

    @property
    def tags(self) -> frozenset[str]:
        """The set of tags on this entity (immutable view)."""
        return frozenset(self._tags)

    def add_tag(self, tag: str) -> None:
        """Add a tag to this entity."""
        self._tags.add(tag)

    def remove_tag(self, tag: str) -> None:
        """Remove a tag; no-op if absent."""
        self._tags.discard(tag)

    def has_tag(self, tag: str) -> bool:
        """Return True if this entity has the given tag."""
        return tag in self._tags

    def to_dict(self) -> dict[str, Any]:
        return {
            "entity_id": self.entity_id,
            "name": self.name,
            "enabled": self.enabled,
            "layer": self.layer,
            "parent_id": self.parent_id,
            "components": [c.to_dict() for c in self._components],
            "tags": sorted(self._tags),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Entity:
        entity = cls(
            name=str(data["name"]),
            entity_id=str(data["entity_id"]),
            enabled=bool(data.get("enabled", True)),
            layer=int(data.get("layer", 0)),
            parent_id=data.get("parent_id"),
        )
        for tag in data.get("tags", []):
            entity.add_tag(str(tag))
        for component_data in data.get("components", []):
            with contextlib.suppress(ValueError, KeyError):
                entity.add_component(component_from_dict(component_data))
        return entity

    def __repr__(self) -> str:
        return f"Entity({self.name!r}, id={self.entity_id!r})"
