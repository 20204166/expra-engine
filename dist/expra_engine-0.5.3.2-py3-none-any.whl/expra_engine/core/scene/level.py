"""Level — a playable spatial document reusing the Scene entity graph."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, cast

from expra_engine.core.document_kind import DocumentKind
from expra_engine.core.scene.scene import Scene
from expra_engine.observability import ObservabilityWatcher

__all__ = ("Level", "LevelMetadata")


@dataclass(frozen=True)
class LevelMetadata:
    """Whole-level semantics only; entity/component state lives in the graph.

    These are the sanctioned level-scoped fields. Lists of enemies, walls,
    pickups, doors, etc. remain ordinary entities/components, never metadata.
    """

    display_name: str | None = None
    world_bounds: tuple[float, float, float, float] | None = None
    spawn_entity_id: str | None = None
    default_camera_id: str | None = None
    tags: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return {
            "display_name": self.display_name,
            "world_bounds": list(self.world_bounds) if self.world_bounds is not None else None,
            "spawn_entity_id": self.spawn_entity_id,
            "default_camera_id": self.default_camera_id,
            "tags": list(self.tags),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LevelMetadata:
        bounds = data.get("world_bounds")
        return cls(
            display_name=data.get("display_name"),
            world_bounds=tuple(bounds) if bounds else None,
            spawn_entity_id=data.get("spawn_entity_id"),
            default_camera_id=data.get("default_camera_id"),
            tags=tuple(data.get("tags", ())),
        )


class Level(Scene):
    """A playable spatial document built on the ordinary Scene entity graph.

    A Level is a Scene (not a parallel world model): it reuses entities,
    hierarchy, transforms, components, selection, commands, rendering, physics,
    animation, behaviour and audio. The only additions are the LEVEL document
    kind and a small ``LevelMetadata`` payload. No ``LevelEntity``,
    ``LevelComponent``, or ``LevelHierarchy`` types exist.
    """

    document_kind = DocumentKind.LEVEL

    def __init__(
        self,
        name: str,
        *,
        scene_id: str | None = None,
        camera: dict[str, Any] | Any | None = None,
        level_metadata: LevelMetadata | None = None,
    ) -> None:
        super().__init__(name, scene_id=scene_id, camera=camera)
        self.level_metadata = level_metadata if level_metadata is not None else LevelMetadata()

    def to_dict(self, *, include_instance_content: bool = True) -> dict[str, Any]:
        data = super().to_dict(include_instance_content=include_instance_content)
        data["kind"] = self.document_kind.value
        data["level_metadata"] = self.level_metadata.to_dict()
        return data

    def find_anchor(self, anchor_id: str):
        """Return the ordinary Level entity and anchor marker for one ID."""
        from expra_engine.runtime.level_anchor import LevelAnchorComponent

        self.validate_anchors()
        return next(
            (
                (entity, component)
                for entity in self.entities
                if (component := entity.get_component(LevelAnchorComponent)) is not None
                and component.anchor_id == anchor_id
            ),
            None,
        )

    def validate_anchors(self) -> None:
        """Reject duplicate named anchors before a Level can be used by a World."""
        from expra_engine.runtime.level_anchor import LevelAnchorComponent

        seen: set[str] = set()
        for entity in self.entities:
            component = entity.get_component(LevelAnchorComponent)
            if component is None:
                continue
            if component.anchor_id in seen:
                raise ValueError(f"duplicate Level anchor ID: {component.anchor_id!r}")
            seen.add(component.anchor_id)

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        *,
        observer: ObservabilityWatcher | None = None,
    ) -> Level:
        level = cast(Level, super().from_dict(data, observer=observer))
        level.level_metadata = LevelMetadata.from_dict(data.get("level_metadata", {}))
        level.validate_anchors()
        return level
