"""Main editor window — composition root.

Wires together:
    AppCoordinator (work)
    ButtonCoordinator (actions)
    UICoordinator (presentation)
    Engine (game state)
    Editor panels (hierarchy, viewport, inspector, console)

Threading invariant: ALL Tk mutations on the main thread.
Background work delivers results through TkDeliveryQueue → AppCoordinator
→ callback on Tk main thread.  Never call widget.after_idle() from a worker.
"""

from __future__ import annotations

import contextlib
import logging
import tkinter as tk
from collections.abc import Sequence
from dataclasses import replace
from pathlib import Path
from tkinter import messagebox
from tkinter import ttk as tkttk
from typing import Any

import ttkbootstrap as ttk

from expra_engine.coordinators.app_coordinator import AppCoordinator
from expra_engine.coordinators.button_coordinator import ButtonCoordinator
from expra_engine.coordinators.ui_coordinator import RenderIntent, UICoordinator
from expra_engine.core.component import TransformComponent, registered_component_types
from expra_engine.core.document_kind import DocumentKind
from expra_engine.core.engine import Engine, EngineRunState
from expra_engine.core.scene import Scene
from expra_engine.editor.active_document import ActiveDocument
from expra_engine.editor.builtin_features import build_builtin_features
from expra_engine.editor.commands import (
    AddComponentCommand,
    Command,
    CreateEntityCommand,
    DeleteEntityCommand,
    RenameEntityCommand,
    SetExposedValueCommand,
    ToggleEnabledCommand,
    TransformEntityCommand,
)
from expra_engine.editor.contributions import (
    ContributionRegistry,
    EditorContext,
    MenuFactory,
    ShortcutRegistry,
)
from expra_engine.editor.delivery import TkDeliveryQueue
from expra_engine.editor.document_actions import EditorDocumentSurface
from expra_engine.editor.export_dialog import ExportDialog
from expra_engine.editor.interactions import (
    apply_component_change,
    delete_selection,
    duplicate_selection,
    remove_component,
    reparent_selection_to,
)
from expra_engine.editor.normal_map_actions import NormalMapEditorActionsMixin
from expra_engine.editor.preferences import PreferencesStore
from expra_engine.editor.project_workflow import ProjectWorkflow
from expra_engine.editor.render_targets import RenderTargetRegistry
from expra_engine.editor.runtime_preview import RuntimePreviewLoop
from expra_engine.editor.script_actions import ScriptEditorActionsMixin
from expra_engine.editor.window_placement import WindowGeometry, initial_hierarchy_width
from expra_engine.editor.world_authoring import WorldEditorActionsMixin
from expra_engine.observability import ObservabilityWatcher
from expra_engine.runtime.input import PhysicalInput
from expra_engine.runtime.script_component import ScriptComponent
from expra_engine.ui.asset_browser import AssetBrowserPanel
from expra_engine.ui.console import ConsolePanel
from expra_engine.ui.hierarchy import HierarchyPanel
from expra_engine.ui.inspector import InspectorPanel
from expra_engine.ui.styles import (
    STYLE_APP_FRAME,
    STYLE_PANEL_FRAME,
    accent_theme_colors,
    configure_app_styles,
)
from expra_engine.ui.timer_delivery import TimerDelivery
from expra_engine.ui.toolbar import build_toolbar
from expra_engine.ui.viewport import ViewportPanel

LOGGER = logging.getLogger(__name__)
_WINDOW_WIDTH = 1280
_WINDOW_HEIGHT = 800
_WINDOW_MIN_WIDTH = 980
_WINDOW_MIN_HEIGHT = 640
_HIERARCHY_MIN_WIDTH = 190
_INSPECTOR_WIDTH = 300
_INSPECTOR_MIN_WIDTH = 260
_BOTTOM_HEIGHT = 150
_BOTTOM_MIN_HEIGHT = 96
_PREFERENCES_PATH = Path.home() / ".expra" / "preferences.json"
_VIEWPORT_CAMERA_SAVE_DEBOUNCE_MS = 400


class EditorWindow(
    EditorDocumentSurface,
    WorldEditorActionsMixin,
    NormalMapEditorActionsMixin,
    ScriptEditorActionsMixin,
):
    """Root editor window."""

    def __init__(self, engine: Engine, *, theme: str = "bootstrap-dark") -> None:
        self._engine = engine
        self._active_document = ActiveDocument()
        self._is_closing = False
        self._pending_timer_ids: set[str] = set()
        self._sash_after_id: str | None = None
        self._autosave_after_id: str | None = None
        self._viewport_camera_save_after_id: str | None = None
        self._preferences_path = _PREFERENCES_PATH
        self._preferences_store = PreferencesStore()
        self._preferences = self._preferences_store.load(self._preferences_path)

        # Root window — ttkbootstrap Window replaces bare tk.Tk
        try:
            self._root = ttk.Window(themename=theme)
        except tk.TclError:
            self._root = ttk.Window(themename="darkly")
        self._root.title("Expra Editor")
        self._root.geometry(f"{_WINDOW_WIDTH}x{_WINDOW_HEIGHT}")
        saved_geometry = WindowGeometry.from_tk_geometry(self._preferences.window_geometry or "")
        if saved_geometry is not None:
            self._root.geometry(saved_geometry.to_tk_geometry())
        self._root.minsize(_WINDOW_MIN_WIDTH, _WINDOW_MIN_HEIGHT)
        self._root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._root.bind("<KeyPress>", self._on_runtime_key_press, add="+")
        self._root.bind("<KeyRelease>", self._on_runtime_key_release, add="+")
        self._colors = accent_theme_colors("cyan")
        self._style = tkttk.Style(self._root)
        configure_app_styles(self._style, colors=self._colors)
        self._root.configure(background=self._colors["background"])

        # Thread-safe delivery queue — worker threads enqueue, Tk drains
        self._delivery_queue = TkDeliveryQueue(self._root)

        # Shared across the whole application session -- AppCoordinator,
        # ButtonCoordinator, UICoordinator, the viewport's render
        # extraction/plan/pixel bridge, and the Engine (injected below) --
        # so a single snapshot() reports app/ui/runtime/render/editor
        # metrics together (see performance_probe's use of this for
        # regression data).
        self._observer = ObservabilityWatcher()
        self._engine.observer = self._observer

        # Coordinators
        self._coordinator = AppCoordinator(deliver=self._delivery_queue, observer=self._observer)
        self._actions = ButtonCoordinator(observer=self._observer)
        self._ui = UICoordinator(observer=self._observer)
        self._editor_context = EditorContext(
            engine=self._engine,
            actions=self._actions,
            ui=self._ui,
            app=self._coordinator,
            root=self._root,
            project=self._engine.project,
        )
        self._shortcuts = ShortcutRegistry()
        self._contributions = ContributionRegistry(
            self._actions,
            context=self._editor_context,
            shortcuts=self._shortcuts,
        )
        self._render_targets = RenderTargetRegistry()

        self._timer = TimerDelivery(
            master=self._root,
            is_closing=lambda: self._is_closing,
            pending_ids=self._pending_timer_ids,
            logger=LOGGER,
        )
        self._render_generations: dict[str, int] = {"inspector": 0}
        self._render_owners: dict[str, str | None] = {"inspector": None}
        self._project_workflow = ProjectWorkflow(self)
        self._runtime_preview = RuntimePreviewLoop(
            self._root,
            self._engine,
            lambda: self._request_render(
                "viewport", (self._engine.active_scene, None), priority=20
            ),
            observer=self._observer,
            on_world_startup_diagnostic=lambda message: self._console.log(
                f"[World] {message}", level="error"
            ),
            on_world_startup_error=self._act_stop,
            on_runtime_error=lambda message: self._console.log(message, level="error"),
        )

        self._register_actions()
        self._build_layout()
        self._create_default_scene()
        self._start_autosave()

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------

    def _on_runtime_key_press(self, event: Any) -> None:
        self._forward_runtime_key("press", getattr(event, "keysym", ""))

    def _on_runtime_key_release(self, event: Any) -> None:
        self._forward_runtime_key("release", getattr(event, "keysym", ""))

    def _forward_runtime_key(self, phase: str, key: object) -> None:
        if self._engine.run_state not in (EngineRunState.PLAY, EngineRunState.PAUSED):
            return
        control = str(key).lower()
        if not control:
            return
        observer = self._observer
        token = observer.begin("runtime:input:dispatch") if observer is not None else None
        transitions: tuple[Any, ...] = ()
        try:
            transitions = getattr(self._engine.input_map, phase)(PhysicalInput("keyboard", control))
            for action_event in transitions:
                self._engine.signal(action_event)
        finally:
            if observer is not None:
                observer.increment("runtime:input:dispatch", "physical_inputs")
                observer.increment("runtime:input:dispatch", "action_events", len(transitions))
                if token is not None:
                    observer.finish(token)

    def _build_layout(self) -> None:
        self._build_menubar()
        main = ttk.Frame(self._root, style=STYLE_APP_FRAME)
        main.pack(fill="both", expand=True)

        # Toolbar at top
        self._toolbar = build_toolbar(
            main,
            actions=self._actions,
            contributions=self._contributions.toolbar_contributions(),
        )

        # Center and console are independently resizable; the viewport gets the
        # flexible weight while side panes retain usable minimum widths.
        self._main_paned = ttk.Panedwindow(main, orient="vertical")
        self._main_paned.pack(fill="both", expand=True, pady=(2, 0))
        center = ttk.Frame(self._main_paned, style=STYLE_APP_FRAME)
        self._main_paned.add(center, weight=1)
        self._console_host = ttk.Frame(self._main_paned, style=STYLE_PANEL_FRAME)
        self._main_paned.add(self._console_host, weight=0)
        self._main_paned.bind("<Configure>", self._clamp_vertical_sash, add="+")

        self._content_paned = ttk.Panedwindow(center, orient="horizontal")
        self._content_paned.pack(fill="both", expand=True)

        # Left pane: hierarchy and project assets
        hier_frame = ttk.Frame(
            self._content_paned,
            width=500,
            style=STYLE_PANEL_FRAME,
        )
        left_paned = ttk.Panedwindow(hier_frame, orient="vertical")
        left_paned.pack(fill="both", expand=True)
        hierarchy_host = ttk.Frame(left_paned, style=STYLE_PANEL_FRAME)
        assets_host = ttk.Frame(left_paned, style=STYLE_PANEL_FRAME)
        left_paned.add(hierarchy_host, weight=3)
        left_paned.add(assets_host, weight=2)
        self._hierarchy = HierarchyPanel(
            hierarchy_host,
            colors=self._colors,
            actions=self._actions,
            on_select=self._on_hierarchy_select,
            on_create=self._on_hierarchy_create,
            on_add_level=self._act_add_world_level,
            on_create_connection=self._act_create_world_connection,
            on_open_level=self._open_world_level,
            on_delete=self._on_hierarchy_delete,
            on_reparent=lambda ids, target: reparent_selection_to(self, ids, target),
        )
        self._hierarchy.pack(fill="both", expand=True)
        # Root directory is the whole project (not just assets_dir) so reusable
        # Scene files also appear here, browsable and draggable, per spec.
        project_assets = (
            self._engine.project.path if self._engine.project is not None else Path.cwd() / "assets"
        )
        self._assets = AssetBrowserPanel(
            assets_host,
            root_directory=project_assets,
            resource_root=project_assets,
            coordinator=self._coordinator,
            observer=self._observer,
            colors=self._colors,
            on_open=self._on_asset_open,
            on_drop=self._on_asset_drop,
        )
        self._assets.pack(fill="both", expand=True)
        self._hierarchy_host = hierarchy_host
        self._assets_host = assets_host
        self._left_paned = left_paned
        self._content_paned.add(hier_frame, weight=0)

        # Center pane: viewport
        view_frame = ttk.Frame(self._content_paned, style=STYLE_APP_FRAME)
        self._viewport = ViewportPanel(
            view_frame,
            on_entity_click=self._on_viewport_entity_click,
            camera_state=self._preferences.viewport_camera,
            on_camera_change=self._save_viewport_camera,
            resource_service=(
                self._engine.project.resource_service(observer=self._observer)
                if self._engine.project is not None
                else None
            ),
            observer=self._observer,
            on_transform_commit=self._push_spatial_command,
        )
        self._viewport.pack(fill="both", expand=True)
        self._viewport_host = view_frame
        self._content_paned.add(view_frame, weight=1)

        # Right pane: inspector
        insp_frame = ttk.Frame(
            self._content_paned,
            width=_INSPECTOR_WIDTH,
            style=STYLE_PANEL_FRAME,
        )
        self._inspector = InspectorPanel(
            insp_frame,
            colors=self._colors,
            on_transform_change=self._on_transform_change,
            on_rename=self._on_entity_rename,
            on_toggle_enabled=self._on_entity_toggle,
            on_script_value_change=self._on_script_value_change,
            on_add_component=self._on_add_component,
            on_component_change=lambda *args: apply_component_change(self, *args),
            on_remove_component=lambda *args: remove_component(self, *args),
            on_world_level_placement=self._on_world_level_placement,
            on_world_set_initial_level=self._on_world_set_initial_level,
            on_world_remove_item=self._on_world_remove_item,
            on_normal_map_preview=self._on_normal_map_preview,
            on_normal_map_auto_map=self._on_normal_map_auto_map,
        )
        self._inspector.pack(fill="both", expand=True)
        self._inspector_host = insp_frame
        self._content_paned.add(insp_frame, weight=0)
        self._content_paned.bind("<Configure>", self._clamp_horizontal_sashes, add="+")

        # Bottom: console (fixed height)
        self._console = ConsolePanel(self._console_host, colors=self._colors)
        self._console.pack(fill="both", expand=True)
        self._register_render_targets()
        self._root.update_idletasks()
        self._sash_after_id = self._root.after_idle(self._set_initial_sashes)
        self._assets.refresh()

    def _on_asset_open(self, entry: Any) -> None:
        self._project_workflow.open_asset(entry)

    def _set_initial_sashes(self) -> None:
        """Place side panes after Tk has measured the initial shell."""
        self._sash_after_id = None
        try:
            width = self._content_paned.winfo_width()
            height = self._main_paned.winfo_height()
            if width <= 1 or height <= 1:
                return

            hierarchy_width = initial_hierarchy_width(width)
            self._content_paned.sashpos(0, hierarchy_width)
            self._content_paned.sashpos(1, max(hierarchy_width + 260, width - _INSPECTOR_WIDTH))
            self._main_paned.sashpos(0, max(300, height - _BOTTOM_HEIGHT))
            self._clamp_horizontal_sashes()
            self._clamp_vertical_sash()
        except tk.TclError:
            return

    def show_project_welcome(self) -> None:
        """Show a small non-blocking project manager for no-project startup."""
        welcome = tk.Toplevel(self._root)
        welcome.title("Expra Project Manager")
        welcome.transient(self._root)
        welcome.resizable(False, False)
        tk.Label(
            welcome,
            text="Start an Expra game project",
            padx=24,
            pady=16,
        ).pack()
        tk.Label(
            welcome,
            text="Create a new project or open an existing project workspace.",
            padx=24,
            pady=12,
        ).pack()
        buttons = tk.Frame(welcome)
        buttons.pack(padx=18, pady=(0, 18), fill="x")
        tk.Button(buttons, text="New Project", command=self._act_new_project).pack(
            side="left", padx=4
        )
        tk.Button(buttons, text="Open Project", command=self._act_open_project).pack(
            side="left", padx=4
        )
        tk.Button(buttons, text="Continue Scratch Scene", command=welcome.destroy).pack(
            side="left", padx=4
        )

    def _clamp_horizontal_sashes(self, _event: Any = None) -> None:
        try:
            width = self._content_paned.winfo_width()
            if width <= 1:
                return
            max_first = width - _INSPECTOR_MIN_WIDTH - 260
            if max_first < _HIERARCHY_MIN_WIDTH:
                return
            first = min(max(_HIERARCHY_MIN_WIDTH, self._content_paned.sashpos(0)), max_first)
            second = min(
                max(first + 260, self._content_paned.sashpos(1)), width - _INSPECTOR_MIN_WIDTH
            )
            self._content_paned.sashpos(0, first)
            self._content_paned.sashpos(1, second)
        except tk.TclError:
            return

    def _clamp_vertical_sash(self, _event: Any = None) -> None:
        try:
            height = self._main_paned.winfo_height()
            if height > 1:
                position = min(max(300, self._main_paned.sashpos(0)), height - _BOTTOM_MIN_HEIGHT)
                self._main_paned.sashpos(0, position)
        except tk.TclError:
            return

    def _build_menubar(self) -> None:
        menubar = tk.Menu(self._root)
        self._root.configure(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        self._file_menu = file_menu
        self._recent_menu = tk.Menu(file_menu, tearoff=0)
        file_menu.add_cascade(label="Open Recent", menu=self._recent_menu)
        self._populate_recent_projects()
        file_menu.add_separator()
        file_menu.add_command(label="Quit", command=self._on_close)

        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        self._edit_menu = edit_menu
        view_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="View", menu=view_menu)
        self._preview_lighting_var = tk.BooleanVar(master=self._root, value=True)
        view_menu.add_checkbutton(
            label="Preview Lighting",
            variable=self._preview_lighting_var,
            command=self._act_preview_lighting_changed,
        )
        MenuFactory({"File": file_menu, "Edit": edit_menu}).build(
            self._contributions.menu_contributions(),
            self._actions,
        )
        self._save_menu_index = file_menu.index("Save Scene")
        self._save_as_menu_index = file_menu.index("Save Scene As...")

    def _register_render_targets(self) -> None:
        self._render_targets.register("hierarchy", self._render_hierarchy)
        self._render_targets.register("inspector", self._render_inspector)
        self._render_targets.register("viewport", self._render_viewport)
        self._render_targets.register("toolbar", self._render_toolbar)

    def _render_hierarchy(self, intent: RenderIntent) -> None:
        self._hierarchy.render(intent.payload)

    def _render_inspector(self, intent: RenderIntent) -> None:
        if self._editing_world_document():
            self._inspector.render_world(
                self._active_document.document,
                self._selected_id,
            )
            return
        self._inspector.render(intent.payload)

    def _render_toolbar(self, _intent: RenderIntent) -> None:
        self._update_play_pause_state()

    def _act_preview_lighting_changed(self) -> None:
        """Refresh the edit viewport without changing authored camera settings."""
        self._request_render(
            "viewport",
            (self._engine.active_scene, tuple(self._selected_ids)),
            priority=10,
        )

    def _act_export_game(self) -> None:
        if self._engine.project is None:
            messagebox.showwarning("Export Game", "Open a project before exporting.")
            return
        ExportDialog(
            self._root,
            self._engine.project.path,
            self._coordinator,
            self._actions,
            game_version=self._engine.project.game_version,
            entry_point=self._engine.project.entry_point,
        )

    def _act_undo(self) -> None:
        cmd = self._command_stack.undo()
        if cmd is not None:
            self._console.log(f"[Edit] Undo: {cmd.description}")
            self._present_all()
        self._update_undo_redo_state()

    def _act_redo(self) -> None:
        cmd = self._command_stack.redo()
        if cmd is not None:
            self._console.log(f"[Edit] Redo: {cmd.description}")
            self._present_all()
        self._update_undo_redo_state()

    def _update_undo_redo_state(self) -> None:
        self._actions.set_enabled("undo", self._command_stack.can_undo)
        self._actions.set_enabled("redo", self._command_stack.can_redo)

    def _register_actions(self) -> None:
        for feature in build_builtin_features(self):
            self._contributions.register(feature)
        self._shortcuts.bind(self._root, self._actions)
        self._update_play_pause_state()

    # Engine actions
    # ------------------------------------------------------------------

    def _act_play(self) -> None:
        if self._engine.play():
            self._console.log("[Engine] Play", level="info")
            self._runtime_preview.start()
        self._update_play_pause_state()
        self._present_all()

    def _act_pause(self) -> None:
        if self._engine.pause():
            self._console.log("[Engine] Paused", level="info")
        self._update_play_pause_state()
        self._present_all()

    def _act_stop(self) -> None:
        self._runtime_preview.stop()
        self._project_workflow.stop_project()
        if self._engine.stop():
            self._console.log("[Engine] Stopped — scene restored", level="info")
        self._project_workflow.restore_after_run_project()
        self._update_play_pause_state()
        self._present_all()

    # ------------------------------------------------------------------
    # Project and scene actions
    # ------------------------------------------------------------------
    def _start_autosave(self) -> None:
        """Schedule recurring silent saves using the configured preference."""
        interval_ms = max(1, int(self._preferences.autosave_interval_ms))

        def autosave() -> None:
            self._autosave_after_id = None
            self._act_save_scene_silent()
            if not self._is_closing:
                self._autosave_after_id = self._root.after(interval_ms, autosave)

        if self._autosave_after_id is not None:
            with contextlib.suppress(tk.TclError):
                self._root.after_cancel(self._autosave_after_id)
        self._autosave_after_id = self._root.after(interval_ms, autosave)

    def _populate_recent_projects(self) -> None:
        self._recent_menu.delete(0, "end")
        recent_projects = tuple(self._preferences.recent_projects)
        if not recent_projects:
            self._recent_menu.add_command(label="(none)", state="disabled")
            return
        for project in recent_projects:
            self._recent_menu.add_command(
                label=project,
                command=self._recent_project_command(project),
            )

    def _act_add_entity(self) -> None:
        if self._engine.run_state != EngineRunState.EDIT:
            return
        self._on_hierarchy_create()

    def _act_delete_entity(self) -> None:
        if len(self._selected_ids) == 1:
            self._on_hierarchy_delete(self._selected_ids[0])
        elif self._selected_ids:
            delete_selection(self)

    def _act_duplicate_selection(self) -> None:
        duplicate_selection(self)

    def _on_hierarchy_select(self, ids: Sequence[str]) -> None:
        """Central selection setter: dedupes, drops dead ids, updates dependent action state."""
        scene, entity = self._set_selection_state(ids)
        self._present_selection(scene, entity)

    def _set_selection_state(self, ids: Sequence[str]) -> tuple[Scene | None, Any | None]:
        """Set the canonical selection and its action state without presenting it."""
        if self._apply_world_selection(ids):
            return None, None
        scene = self._engine.active_scene
        valid = tuple(
            dict.fromkeys(i for i in ids if scene is None or scene.find_entity(i) is not None)
        )
        self._selected_ids = valid
        primary_id = valid[0] if valid else None
        self._actions.set_enabled("delete_entity", bool(valid))
        self._actions.set_enabled("duplicate_selection", bool(valid))
        entity = scene.find_entity(primary_id) if scene and primary_id else None
        has_script = bool(
            entity is not None
            and any(isinstance(component, ScriptComponent) for component in entity.components)
        )
        self._actions.set_enabled("attach_script", primary_id is not None and not has_script)
        self._actions.set_enabled("remove_script", has_script)
        return scene, entity

    def _on_add_component(self, component_name: str) -> None:
        if self._engine.run_state != EngineRunState.EDIT or self._selected_id is None:
            return
        scene = self._engine.edit_scene
        entity = scene.find_entity(self._selected_id) if scene else None
        component_type = dict(registered_component_types()).get(component_name)
        if entity is None or component_type is None:
            return
        if any(isinstance(component, component_type) for component in entity.components):
            return
        try:
            self._command_stack.push(AddComponentCommand(scene, entity.entity_id, component_type))
        except TypeError as exc:
            messagebox.showerror("Add Component", str(exc), parent=self._root)
            return
        self._console.log(f"[Editor] Added {component_name} to {entity.name}")
        self._present_all()

    # ------------------------------------------------------------------
    # Hierarchy callbacks
    # ------------------------------------------------------------------

    def _on_hierarchy_create(self) -> None:
        if self._engine.run_state != EngineRunState.EDIT:
            return
        scene = self._engine.edit_scene
        if scene is None:
            scene = Scene("New Scene")
            self._engine.set_scene(scene)
        entity = scene.create_entity("Entity")
        entity.add_component(TransformComponent())
        self._command_stack.push(CreateEntityCommand(scene, entity))
        self._update_undo_redo_state()
        self._set_selection_state((entity.entity_id,))
        self._console.log(f"[Editor] Created entity: {entity.name}")
        self._present_all()

    def _on_hierarchy_delete(self, entity_id: str) -> None:
        if self._engine.run_state != EngineRunState.EDIT:
            return
        scene = self._engine.edit_scene
        if scene is None:
            return
        entity = scene.find_entity(entity_id)
        if entity is None:
            return
        cmd = DeleteEntityCommand(scene, entity)
        self._command_stack.push(cmd)
        self._console.log(f"[Editor] Deleted entity: {entity.name}")
        self._set_selection_state(
            tuple(selected_id for selected_id in self._selected_ids if selected_id != entity_id)
        )
        self._update_undo_redo_state()
        self._present_all()

    _TRANSFORM_FIELDS = ("x", "y", "rotation", "scale_x", "scale_y")

    def _on_transform_change(self, entity_id: str, field: str, value: float) -> None:
        if self._engine.run_state != EngineRunState.EDIT or field not in self._TRANSFORM_FIELDS:
            return
        scene = self._engine.edit_scene
        if scene is None:
            return
        entity = scene.find_entity(entity_id)
        if entity is None:
            return
        transform = entity.get_component(TransformComponent)
        if transform is None:
            return
        old = tuple(getattr(transform, name) for name in self._TRANSFORM_FIELDS)
        index = self._TRANSFORM_FIELDS.index(field)
        new = tuple(value if i == index else old[i] for i in range(len(old)))
        if new == old:
            return
        self._command_stack.push(TransformEntityCommand(scene, entity_id, old, new))
        self._update_undo_redo_state()
        self._request_render("viewport", (scene, self._selected_ids), priority=10)

    def _on_entity_rename(self, entity_id: str, new_name: str) -> None:
        if self._engine.run_state != EngineRunState.EDIT:
            return
        scene = self._engine.edit_scene
        if scene is None:
            return
        entity = scene.find_entity(entity_id)
        if entity is None:
            return
        cmd = RenameEntityCommand(entity, entity.name, new_name)
        self._command_stack.push(cmd)
        self._update_undo_redo_state()
        self._ui.begin_batch()
        self._request_render("hierarchy", scene, priority=20)
        self._request_render("viewport", (scene, self._selected_ids), priority=10)
        self._ui.end_batch()
        self._hierarchy.select(entity_id)

    def _on_entity_toggle(self, entity_id: str, enabled: bool) -> None:
        if self._engine.run_state != EngineRunState.EDIT:
            return
        scene = self._engine.edit_scene
        if scene is None:
            return
        entity = scene.find_entity(entity_id)
        if entity is None or entity.enabled == enabled:
            return
        self._command_stack.push(ToggleEnabledCommand(scene, entity_id, entity.enabled, enabled))
        self._update_undo_redo_state()
        self._present_all()

    # ------------------------------------------------------------------
    # Inspector callbacks
    # ------------------------------------------------------------------

    def _on_script_value_change(
        self, entity_id: str, component_index: int, field: str, value: Any
    ) -> None:
        if self._engine.run_state != EngineRunState.EDIT:
            return
        scene = self._engine.edit_scene
        if scene is None or scene.find_entity(entity_id) is None:
            return
        self._command_stack.push(
            SetExposedValueCommand(scene, entity_id, component_index, field, value)
        )
        self._update_undo_redo_state()
        self._present_all()

    def _on_viewport_entity_click(self, ids: tuple[str, ...], extend: bool) -> None:
        """Plain click replaces selection; Shift/Ctrl toggles a single entity or extends (box-select)."""
        if not extend:
            new_ids = ids
        elif len(ids) == 1 and ids[0] in self._selected_ids:
            new_ids = tuple(i for i in self._selected_ids if i != ids[0])
        else:
            new_ids = tuple(dict.fromkeys((*self._selected_ids, *ids)))
        self._on_hierarchy_select(new_ids)

    def _save_viewport_camera(self, values: dict[str, object]) -> None:
        # Pan/zoom/rotate fire this on every mouse-motion tick -- update the
        # in-memory value immediately (cheap) but debounce the actual disk
        # write (atomic write + fsync, measured ~4-8ms) so a sustained drag
        # doesn't serialize preferences dozens of times per second on the Tk
        # main thread. The trailing write always lands: _on_close flushes any
        # still-pending write before cancel_all() would otherwise drop it.
        self._preferences = replace(self._preferences, viewport_camera=values)
        self._timer.cancel(self._viewport_camera_save_after_id)
        self._viewport_camera_save_after_id = self._timer.schedule(
            _VIEWPORT_CAMERA_SAVE_DEBOUNCE_MS, self._flush_viewport_camera_prefs
        )

    def _flush_viewport_camera_prefs(self) -> None:
        self._viewport_camera_save_after_id = None
        self._preferences_store.save(self._preferences_path, self._preferences)

    # Refresh helpers

    def _refresh_viewport(self) -> None:
        self._request_render(
            "viewport",
            (self._engine.active_scene, self._selected_ids),
            priority=10,
        )

    def _refresh_all(self) -> None:
        self._present_all()

    def _push_spatial_command(self, command: Command) -> None:
        """Commit one viewport drag gesture (move/rotate/scale) as one undo entry."""
        self._command_stack.push(command)
        self._console.log(f"[Editor] {command.description}")
        self._update_undo_redo_state()
        self._present_all()

    def _update_play_pause_state(self) -> None:
        state = self._engine.run_state
        entity_editable = (
            state == EngineRunState.EDIT and self._active_document.kind is not DocumentKind.WORLD
        )
        self._actions.set_enabled("play", state != EngineRunState.PLAY)
        self._actions.set_enabled("pause", state == EngineRunState.PLAY)
        self._actions.set_enabled("stop", state != EngineRunState.EDIT)
        self._actions.set_enabled("add_entity", entity_editable)
        self._actions.set_enabled("delete_entity", entity_editable and bool(self._selected_ids))
        self._actions.set_enabled(
            "duplicate_selection", entity_editable and bool(self._selected_ids)
        )
        self._update_project_actions()

    def _update_project_actions(self) -> None:
        has_project = self._engine.project is not None
        self._actions.set_enabled("save_document", has_project)
        self._actions.set_enabled("save_scene", has_project)
        self._actions.set_enabled("close_project", has_project)
        self._actions.set_enabled("new_script", has_project)
        self._actions.set_enabled("import_asset", has_project)
        self._actions.set_enabled("configure_input", has_project)
        self._actions.set_enabled("editor.export_game", has_project)
        self._refresh_typed_save_labels()

    def _create_default_scene(self) -> None:
        scene = Scene("Sample Scene")
        entity = scene.create_entity("Camera")
        entity.add_component(TransformComponent(x=0, y=0))
        entity2 = scene.create_entity("Player")
        entity2.add_component(TransformComponent(x=80, y=-40))
        self._engine.set_scene(scene)
        self._active_document.open(scene)
        self._console.log("[Editor] Expra Engine started")
        self._console.log(f"[Editor] Loaded scene: {scene.name}")
        self._present_all()

    # ------------------------------------------------------------------
    # Coordinated presentation and lifecycle
    # ------------------------------------------------------------------

    def _request_render(
        self,
        target: str,
        payload: object,
        *,
        owner_id: str | None = None,
        components: frozenset[str] = frozenset(),
        priority: int = 0,
    ) -> None:
        if target == "inspector":
            previous = self._render_owners["inspector"]
            if owner_id is None and previous is not None:
                self._render_generations["inspector"] += 1
                self._ui.clear("inspector")
                self._render_owners["inspector"] = None
            elif owner_id != previous:
                self._render_generations["inspector"] += 1
                self._render_owners["inspector"] = owner_id
                self._ui.invalidate(
                    "inspector",
                    generation=self._render_generations["inspector"],
                    owner_id=owner_id,
                )
            generation = self._render_generations["inspector"]
        else:
            generation = 0
        intent = RenderIntent(
            target=target,
            generation=generation,
            owner_id=owner_id,
            components=components,
            payload=payload,
            payload_set=True,
            priority=priority,
        )
        self._ui.request(intent, self._render_targets.callback_for(target))

    def _render_viewport(self, intent: RenderIntent) -> None:
        payload = intent.payload
        if not isinstance(payload, tuple) or len(payload) != 2:
            return
        scene, selected_ids = payload
        ids = tuple(selected_ids) if selected_ids else ()
        primary_id = ids[0] if ids else None
        runtime_preview = self._engine.run_state in (EngineRunState.PLAY, EngineRunState.PAUSED)
        world_system = self._engine.world_streaming_system
        _ws_active = runtime_preview and world_system is not None
        transition_alpha = world_system.transition_alpha if _ws_active else 0.0
        if not runtime_preview and self._editing_world_document():
            self._viewport.render_world(self._active_document.document, primary_id)
            return
        if (
            intent.components == frozenset({"selection"})
            and scene is self._viewport._scene
            and not runtime_preview
        ):
            self._viewport.update_selection(primary_id, frozenset(ids))
            return
        self._viewport.render(
            scene,
            primary_id,
            selected_ids=frozenset(ids),
            editor_overlays=not runtime_preview,
            interpolator=self._engine.transform_interpolator if runtime_preview else None,
            interpolation_fraction=self._engine.interpolation_fraction if runtime_preview else 0.0,
            animated_players=self._engine.animated_sprite_system.players,
            world_transition_alpha=transition_alpha,
            preview_lighting=(None if runtime_preview else self._preview_lighting_var.get()),
            modulation_entity_ids=world_system.environment_entity_ids if _ws_active else None,
        )

    def _present_selection(self, scene: Scene | None, entity: Any) -> None:
        self._hierarchy.select_many(self._selected_ids)
        self._ui.begin_batch()
        self._request_render("inspector", entity, owner_id=self._selected_id, priority=30)
        self._request_render(
            "viewport",
            (scene, self._selected_ids),
            components=frozenset({"selection"}),
            priority=10,
        )
        self._ui.end_batch()

    def _present_all(self) -> None:
        scene, entity = self._set_selection_state(self._selected_ids)
        hierarchy_document = (
            self._active_document.document
            if self._engine.run_state is EngineRunState.EDIT
            else self._engine.active_scene
        )
        self._ui.begin_batch()
        self._request_render("hierarchy", hierarchy_document, priority=20)
        self._request_render("inspector", entity, owner_id=self._selected_id, priority=30)
        self._request_render("viewport", (scene, self._selected_ids), priority=10)
        self._request_render("toolbar", self._engine.run_state, priority=40)
        self._ui.end_batch()
        self._hierarchy.select_many(self._selected_ids)

    def _on_close(self) -> None:
        self._runtime_preview.stop()
        workflow = getattr(self, "_project_workflow", None)
        if workflow is not None:
            workflow.stop_project()
        self._is_closing = True
        if self._autosave_after_id is not None:
            with contextlib.suppress(tk.TclError):
                self._root.after_cancel(self._autosave_after_id)
            self._autosave_after_id = None
        geometry = WindowGeometry.from_tk_geometry(self._root.geometry())
        if geometry is not None:
            self._preferences = replace(
                self._preferences,
                window_geometry=geometry.to_tk_geometry(),
            )
            with contextlib.suppress(OSError, TypeError, ValueError):
                self._preferences_store.save(self._preferences_path, self._preferences)
        if self._sash_after_id is not None:
            with contextlib.suppress(tk.TclError):
                self._root.after_cancel(self._sash_after_id)
            self._sash_after_id = None
        if self._viewport_camera_save_after_id is not None:
            self._timer.cancel(self._viewport_camera_save_after_id)
            self._viewport_camera_save_after_id = None
            with contextlib.suppress(OSError, TypeError, ValueError):
                self._preferences_store.save(self._preferences_path, self._preferences)
        self._timer.cancel_all()
        self._contributions.stop_all()
        self._delivery_queue.close()
        self._coordinator.shutdown()
        self._ui.shutdown()
        self._root.destroy()

    def run(self) -> None:
        """Start the Tk main loop."""
        self._root.mainloop()
